class SecureStorageConstants {
  static const token = "token";
}
